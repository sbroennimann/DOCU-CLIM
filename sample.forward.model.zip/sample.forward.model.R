library(stringr)
### this is sample code for the forward modeling of phenological data, here for an ice break-up series

### read files, define start/end
x.doc <- read.table("DOCU_CLIM_000637_V1.0_Ice_phenology_St_Petersburg_Newa_River_break-up.txt",header=T)
y.ref <- data.matrix(read.table("DOCU_CLIM_000637_V1.0_RefData_station.txt",header=T))
startyr <- 1751
endyr <- 1850

# cut reference temperature to calibration interval
y.ref <- y.ref[y.ref[,1]>=startyr&y.ref[,1]<=endyr,]
yr.ref <- y.ref[,1]
ref.temp <- y.ref[,-1]
yr.ref <- yr.ref[apply(!is.na(ref.temp),1,sum)==8]
ref.temp <- ref.temp[apply(!is.na(ref.temp),1,sum)==8,]
monnames <- c("Oct","Nov","Dec","Jan","Feb","Mar","Apr","May")
mlist <- cumsum(c(31,29,31,30,31,30,31,31,30,31,30,31))

### select non-missing
doy.doc <- as.numeric(x.doc[,17])
yr.doc <- as.numeric(x.doc[,9])
doy.doc <- doy.doc[!is.na(doy.doc)]
yr.doc <- yr.doc[!is.na(doy.doc)]
sel.yr.ref <- match(yr.doc,yr.ref)
sel.yr.doc <- match(yr.ref,yr.doc)

### regression model
fmodel <- "none"
dataset <- "Station"
fwd.cor <- NA
fwd.pval <- NA
fwd.errvar <- NA
if (sum(!is.na(sel.yr.doc))>20){
 y <- doy.doc[sel.yr.doc[!is.na(sel.yr.doc)]]
 xq <- quantile(y,0.9,na.rm=T)
 xmax <- (which(xq<mlist))[1]
 x <- ref.temp[sel.yr.ref[!is.na(sel.yr.ref)],(xmax-2):(xmax+3)]
 rr <- lm(y~x)
 selv <- summary.lm(rr)$coefficients[-1,4]<0.1
 selv[c(F,sum(selv[1:3])==2,sum(selv[2:4])==2,sum(selv[3:5])==2,sum(selv[4:6])==2,F)] <- T
  if (sum(selv)>0){
   rr <- lm(y~x[,selv])
   fmodel <- paste(monnames[(xmax-2):(xmax+3)][selv],sep="",collapse="")
   fwd.cor <- cor(rr$fitted.values,y)
   fwd.pval <- anova(rr)$Pr[1]
   fwd.errvar <- var(rr$residuals,na.rm=T)}}



